﻿using ChatServer.Net.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;

namespace ChatServer
{
    class Program
    {
        static List<Client> TheUsers   ;
        static TcpListener tcpListener;
        static void Main(string[] args)
        {
            TheUsers = new List<Client>();
            tcpListener = new TcpListener(IPAddress.Parse("127.0.0.1"), 7891);
            tcpListener.Start();

            while (true)
            {
                var client = new Client(tcpListener.AcceptTcpClient());
                TheUsers.Add(client);

                /* Broadcast the connection to everyone on the server */
                BroadcastConnection();
            }
        }

        static void BroadcastConnection()
        {
            foreach (var user in TheUsers)
            {
                foreach (var usr in TheUsers)
                {
                    var broadcastPacket = new PacketBuilder();
                    broadcastPacket.WriteOpCode(1);
                    broadcastPacket.WriteMessage(usr.Username);
                    broadcastPacket.WriteMessage(usr.UID.ToString());
                    user.ClientSocket.Client.Send(broadcastPacket.GetPacketBytes());
                }
            }
        }

        public static void BroadcastMessage(string message)
        {
            foreach (var user in TheUsers)
            {
                var msgPacket = new PacketBuilder();
                msgPacket.WriteOpCode(5);
                msgPacket.WriteMessage(message);
                user.ClientSocket.Client.Send(msgPacket.GetPacketBytes());
            }
        }

        public static void BroadcastDisconnect(string uid)
        {
            var disconnectedUser = TheUsers.Where(x => x.UID.ToString() == uid).FirstOrDefault();
            TheUsers.Remove(disconnectedUser);

            foreach (var user in TheUsers)
            {
                var broadcastPacket = new PacketBuilder();
                broadcastPacket.WriteOpCode(10);
                broadcastPacket.WriteMessage(uid);
                user.ClientSocket.Client.Send(broadcastPacket.GetPacketBytes());
            }

            BroadcastMessage($"[{disconnectedUser.Username}] Disconnected!");
        }
    }
}
