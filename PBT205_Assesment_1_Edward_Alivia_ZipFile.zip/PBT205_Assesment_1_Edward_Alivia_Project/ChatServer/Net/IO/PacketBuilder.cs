﻿using System;
using System.IO;
using System.Text;

namespace ChatServer.Net.IO
{
    class PacketBuilder
    {
        MemoryStream MStream;
        public PacketBuilder()
        {
            MStream = new MemoryStream();
        }

        public void WriteOpCode(byte opcode)
        {
            MStream.WriteByte(opcode);
        }

        public void WriteMessage(string msg)
        {
            var msgLength = msg.Length;
            MStream.Write(BitConverter.GetBytes(msgLength));
            MStream.Write(Encoding.ASCII.GetBytes(msg));
        }

        public byte[] GetPacketBytes()
        {
            return MStream.ToArray();
        }
    }
}
