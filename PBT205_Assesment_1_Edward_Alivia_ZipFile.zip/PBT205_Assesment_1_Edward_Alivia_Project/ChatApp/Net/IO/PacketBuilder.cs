﻿using System;
using System.IO;
using System.Text;

namespace ChatClient.Net.IO
{
    class PacketBuilder
    {
        MemoryStream Mstream;
        public PacketBuilder()
        {
            Mstream = new MemoryStream();
        }

        public void WriteOpCode(byte opcode)
        {
            Mstream.WriteByte(opcode);
        }

        public void WriteMessage(string msg)
        {
            var msgLength = msg.Length;
            Mstream.Write(BitConverter.GetBytes(msgLength));
            Mstream.Write(Encoding.ASCII.GetBytes(msg));
        }

        public byte[] GetPacketBytes()
        {
            return Mstream.ToArray();
        }
    }
}
